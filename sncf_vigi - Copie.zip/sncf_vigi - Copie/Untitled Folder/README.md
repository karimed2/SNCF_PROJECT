# Projet de Détection d’Alertes Transport (IBOO + IVTR)

##  Objectif du projet

Ce projet a pour objectif de construire un système de monitoring de transport public capable de :

- comparer les horaires théoriques (offre planifiée)
- avec les données temps réel (passages observés)
- détecter automatiquement les anomalies
- générer des alertes exploitables (internes et client)

 Cas d’usage :
> Informer les voyageurs en temps réel en cas de retard significatif.

---

## 📡 Sources de données

Le projet utilise les API PRIM d’Île-de-France Mobilités :

- **IBOO** → données théoriques (format NeTEx XML)
- **IVTR** → données temps réel (format JSON SIRI Lite)

---

## Architecture du projet

```text
project/
│
├── notebooks/
│   ├── 05_iboo_theorique.ipynb
│   ├── 01_mvp_detection.ipynb
│   ├── 07_alerts_v2.ipynb
│
├── src/
│   ├── api.py
│   ├── preprocessing.py
│   ├── alerts.py
│
├── data/
│   ├── raw/         # données brutes (XML, API)
│   ├── interim/     # données transformées intermédiaires
│   ├── processed/   # données finales (CSV)
│
└── README.md

## Données

Les données ne sont pas incluses dans le repository car elles sont volumineuses.

Pour reproduire le projet :
1. Télécharger les données IBOO depuis l’API PRIM
2. Placer les fichiers dans data/raw/