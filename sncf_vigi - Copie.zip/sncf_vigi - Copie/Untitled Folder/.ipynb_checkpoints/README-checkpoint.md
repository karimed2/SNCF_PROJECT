# Projet de Détection d’Alertes Transport (IBOO + IVTR)

## Objectif

Ce projet a pour but de comparer les horaires théoriques de transport public avec les données temps réel afin de détecter automatiquement des anomalies comme :

- retard
- retard majeur
- avance anormale
- absence de passage temps réel

Une règle métier importante a été ajoutée : si le retard estimé est supérieur ou égal à 10 minutes, le système génère une **alerte client**.

---

## Sources de données

Le projet utilise les API PRIM d’Île-de-France Mobilités :

- **IBOO** : offre théorique au format NeTEx
- **IVTR** : prochains passages en temps réel

---

## Structure du projet

```text
project/
│
├── notebooks/
│   ├── 05_iboo_theorique.ipynb
│   ├── 06_match_theorique_reel.ipynb
│   ├── 07_alerts_v2.ipynb
│
├── src/
│   ├── api.py
│   ├── preprocessing.py
│   ├── alerts.py
│
├── data/
│   ├── raw/
│   ├── interim/
│   ├── processed/
│
└── README.md