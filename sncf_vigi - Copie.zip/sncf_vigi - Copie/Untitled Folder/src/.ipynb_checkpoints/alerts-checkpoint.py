from __future__ import annotations

import pandas as pd


def build_seq_rank_for_theoretical(df_theo: pd.DataFrame) -> pd.DataFrame:
    theo_seq = (
        df_theo[["stop_ref", "stop_name", "stop_order"]]
        .drop_duplicates()
        .sort_values("stop_order")
        .reset_index(drop=True)
    )
    theo_seq["seq_rank"] = range(1, len(theo_seq) + 1)

    return df_theo.merge(theo_seq[["stop_ref", "seq_rank"]], on="stop_ref", how="left")


def build_seq_rank_for_realtime(df_rt: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    df_rt_valid = df_rt.dropna(subset=["stop_ref", "event_time"]).copy()

    if "call_order" in df_rt_valid.columns and df_rt_valid["call_order"].notna().sum() > 0:
        df_rt_valid["call_order"] = pd.to_numeric(df_rt_valid["call_order"], errors="coerce")
        df_rt_valid = df_rt_valid.dropna(subset=["call_order"]).copy()
        df_rt_valid["call_order"] = df_rt_valid["call_order"].astype(int)

        rt_seq = (
            df_rt_valid[["stop_ref", "stop_name", "call_order"]]
            .drop_duplicates()
            .sort_values("call_order")
            .reset_index(drop=True)
        )
        rt_seq["seq_rank"] = range(1, len(rt_seq) + 1)
    else:
        rt_seq = (
            df_rt_valid.sort_values("event_time")
            .groupby("stop_ref", as_index=False)
            .first()[["stop_ref", "stop_name", "event_time"]]
            .sort_values("event_time")
            .reset_index(drop=True)
        )
        rt_seq["seq_rank"] = range(1, len(rt_seq) + 1)

    df_rt_valid = df_rt_valid.merge(rt_seq[["stop_ref", "seq_rank"]], on="stop_ref", how="left")
    return df_rt_valid, rt_seq


def build_next_departures(df_theo: pd.DataFrame, df_rt: pd.DataFrame, reference_dt: pd.Timestamp) -> tuple[pd.DataFrame, pd.DataFrame]:
    window_start = reference_dt - pd.Timedelta(minutes=10)
    window_end = reference_dt + pd.Timedelta(minutes=120)

    df_theo_window = df_theo[
        (df_theo["planned_time"] >= window_start) &
        (df_theo["planned_time"] <= window_end)
    ].copy()

    df_theo_next = (
        df_theo_window
        .sort_values(["seq_rank", "planned_time"])
        .groupby("seq_rank", as_index=False)
        .first()
    )

    df_rt_next = (
        df_rt
        .sort_values(["seq_rank", "event_time"])
        .groupby("seq_rank", as_index=False)
        .first()
    )

    return df_theo_next, df_rt_next


def compare_theoretical_realtime(df_theo_next: pd.DataFrame, df_rt_next: pd.DataFrame) -> pd.DataFrame:
    df_compare = df_theo_next.merge(
        df_rt_next,
        on=["line_code", "seq_rank"],
        how="left",
        suffixes=("_theo", "_rt"),
    )

    df_compare["delay_min"] = (
        (df_compare["event_time"] - df_compare["planned_time"])
        .dt.total_seconds() / 60
    )

    return df_compare


def build_alerts(df_compare: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    alerts = []

    for _, row in df_compare.iterrows():
        if pd.isna(row["event_time"]):
            alerts.append(
                {
                    "line_code": row["line_code"],
                    "seq_rank": row["seq_rank"],
                    "stop_ref_theo": row.get("stop_ref_theo"),
                    "stop_ref_rt": None,
                    "planned_time": row.get("planned_time"),
                    "event_time": None,
                    "delay_min": None,
                    "alert_type": "missing_realtime_match",
                    "severity": 3,
                    "client_alert": False,
                    "client_message": None,
                }
            )

        elif pd.notna(row["delay_min"]) and row["delay_min"] >= 10:
            alerts.append(
                {
                    "line_code": row["line_code"],
                    "seq_rank": row["seq_rank"],
                    "stop_ref_theo": row.get("stop_ref_theo"),
                    "stop_ref_rt": row.get("stop_ref_rt"),
                    "planned_time": row.get("planned_time"),
                    "event_time": row.get("event_time"),
                    "delay_min": row.get("delay_min"),
                    "alert_type": "major_delay",
                    "severity": 3,
                    "client_alert": True,
                    "client_message": f"Alerte client : retard estimé de {round(row['delay_min'], 1)} minutes.",
                }
            )

        elif pd.notna(row["delay_min"]) and row["delay_min"] > 5:
            alerts.append(
                {
                    "line_code": row["line_code"],
                    "seq_rank": row["seq_rank"],
                    "stop_ref_theo": row.get("stop_ref_theo"),
                    "stop_ref_rt": row.get("stop_ref_rt"),
                    "planned_time": row.get("planned_time"),
                    "event_time": row.get("event_time"),
                    "delay_min": row.get("delay_min"),
                    "alert_type": "delay",
                    "severity": 2,
                    "client_alert": False,
                    "client_message": None,
                }
            )

        elif pd.notna(row["delay_min"]) and row["delay_min"] < -2:
            alerts.append(
                {
                    "line_code": row["line_code"],
                    "seq_rank": row["seq_rank"],
                    "stop_ref_theo": row.get("stop_ref_theo"),
                    "stop_ref_rt": row.get("stop_ref_rt"),
                    "planned_time": row.get("planned_time"),
                    "event_time": row.get("event_time"),
                    "delay_min": row.get("delay_min"),
                    "alert_type": "early",
                    "severity": 1,
                    "client_alert": False,
                    "client_message": None,
                }
            )

    df_alerts = pd.DataFrame(alerts)
    df_client_alerts = df_alerts[df_alerts["client_alert"] == True].copy() if not df_alerts.empty else pd.DataFrame()

    return df_alerts, df_client_alerts