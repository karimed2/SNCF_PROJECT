from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd
from lxml import etree


def get_text(elem: etree._Element, xpath_expr: str) -> str | None:
    try:
        res = elem.xpath(xpath_expr)
    except Exception:
        return None
    if not res:
        return None
    first = res[0]
    if isinstance(first, str):
        return first
    return first.text if hasattr(first, "text") else str(first)


def parse_ivtr_realtime(data: dict) -> pd.DataFrame:
    journeys = (
        data.get("Siri", {})
        .get("ServiceDelivery", {})
        .get("EstimatedTimetableDelivery", [{}])[0]
        .get("EstimatedJourneyVersionFrame", [{}])[0]
        .get("EstimatedVehicleJourney", [])
    )

    rows: list[dict[str, Any]] = []

    for journey in journeys:
        line_ref = journey.get("LineRef", {}).get("value")
        direction_ref = journey.get("DirectionRef", {}).get("value")
        published_line_name = None
        if journey.get("PublishedLineName"):
            published_line_name = journey["PublishedLineName"][0].get("value")

        estimated_calls_container = journey.get("EstimatedCalls", {})
        calls = estimated_calls_container.get("EstimatedCall", []) if isinstance(estimated_calls_container, dict) else []
        if isinstance(calls, dict):
            calls = [calls]

        for call in calls:
            stop_ref = call.get("StopPointRef", {}).get("value") if isinstance(call.get("StopPointRef"), dict) else call.get("StopPointRef")
            stop_name = None
            if call.get("StopPointName"):
                stop_name = call["StopPointName"][0].get("value")

            rows.append(
                {
                    "line_ref": line_ref,
                    "direction_ref": direction_ref,
                    "published_line_name": published_line_name,
                    "stop_ref": stop_ref,
                    "stop_name": stop_name,
                    "call_order": call.get("Order"),
                    "aimed_arrival": call.get("AimedArrivalTime"),
                    "expected_arrival": call.get("ExpectedArrivalTime"),
                    "aimed_departure": call.get("AimedDepartureTime"),
                    "expected_departure": call.get("ExpectedDepartureTime"),
                }
            )

    df = pd.DataFrame(rows)

    for col in ["aimed_arrival", "expected_arrival", "aimed_departure", "expected_departure"]:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    return df


def build_theoretical_from_iboo_xml(xml_path: str | Path) -> pd.DataFrame:
    xml_path = Path(xml_path)
    tree = etree.parse(str(xml_path))
    root = tree.getroot()

    def parse_routes() -> pd.DataFrame:
        rows = []
        for r in root.xpath("//*[local-name()='Route']"):
            rows.append(
                {
                    "route_id": r.get("id"),
                    "line_ref_route": get_text(r, "./*[local-name()='LineRef']/@ref"),
                    "route_name": get_text(r, "./*[local-name()='Name']/text()"),
                }
            )
        return pd.DataFrame(rows)

    def parse_spjp() -> pd.DataFrame:
        rows = []
        for sp in root.xpath("//*[local-name()='StopPointInJourneyPattern']"):
            rows.append(
                {
                    "spjp_id": sp.get("id"),
                    "order_spjp": sp.get("order"),
                    "scheduled_stop_point_ref": get_text(sp, "./*[local-name()='ScheduledStopPointRef']/@ref"),
                }
            )
        return pd.DataFrame(rows)

    def parse_stops() -> pd.DataFrame:
        rows = []
        for stop in root.xpath("//*[local-name()='ScheduledStopPoint']"):
            rows.append(
                {
                    "stop_id": stop.get("id"),
                    "stop_name": get_text(stop, "./*[local-name()='Name']/text()"),
                }
            )
        return pd.DataFrame(rows)

    def parse_service_journeys() -> pd.DataFrame:
        rows = []
        for sj in root.xpath("//*[local-name()='ServiceJourney']"):
            trip_ref = sj.get("id")
            journey_pattern_ref = get_text(sj, "./*[local-name()='JourneyPatternRef']/@ref")
            name = get_text(sj, "./*[local-name()='Name']/text()")
            short_name = get_text(sj, "./*[local-name()='ShortName']/text()")
            private_code = get_text(sj, "./*[local-name()='PrivateCode']/text()")

            passing_times = sj.xpath("./*[local-name()='passingTimes']/*[local-name()='TimetabledPassingTime']")
            if not passing_times:
                passing_times = sj.xpath(".//*[local-name()='TimetabledPassingTime']")

            for idx, t in enumerate(passing_times, start=1):
                rows.append(
                    {
                        "trip_ref": trip_ref,
                        "journey_pattern_ref": journey_pattern_ref,
                        "name": name,
                        "short_name": short_name,
                        "private_code": private_code,
                        "stop_point_in_journey_pattern_ref": get_text(
                            t, "./*[local-name()='StopPointInJourneyPatternRef']/@ref"
                        ),
                        "planned_arrival": get_text(t, "./*[local-name()='ArrivalTime']/text()"),
                        "planned_departure": get_text(t, "./*[local-name()='DepartureTime']/text()"),
                        "stop_order_from_trip": idx,
                    }
                )
        return pd.DataFrame(rows)

    df_routes = parse_routes()
    df_spjp = parse_spjp()
    df_stops = parse_stops()
    df_trip_times = parse_service_journeys()

    df = df_trip_times.merge(
        df_spjp,
        left_on="stop_point_in_journey_pattern_ref",
        right_on="spjp_id",
        how="left",
    )

    df = df.merge(
        df_stops,
        left_on="scheduled_stop_point_ref",
        right_on="stop_id",
        how="left",
    )

    if not df_routes.empty and "line_ref_route" in df_routes.columns and df_routes["line_ref_route"].notna().any():
        line_value = df_routes["line_ref_route"].dropna().iloc[0]
    elif not df_routes.empty and "route_id" in df_routes.columns and df_routes["route_id"].notna().any():
        line_value = df_routes["route_id"].dropna().iloc[0]
    else:
        line_value = xml_path.stem

    df["line_ref"] = line_value
    df["stop_ref"] = df["scheduled_stop_point_ref"]
    df["stop_order"] = pd.to_numeric(
        df["order_spjp"].fillna(df["stop_order_from_trip"]),
        errors="coerce",
    )

    cols_keep = [
        "line_ref",
        "trip_ref",
        "journey_pattern_ref",
        "stop_ref",
        "stop_name",
        "stop_order",
        "planned_arrival",
        "planned_departure",
        "name",
        "short_name",
        "private_code",
    ]

    df = df[cols_keep].copy()
    df = df.dropna(subset=["stop_ref"]).copy()
    df = df.sort_values(["line_ref", "trip_ref", "stop_order"], na_position="last").reset_index(drop=True)

    return df


def prepare_compare_tables(df_theo: pd.DataFrame, df_rt: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame, pd.Timestamp]:
    df_theo = df_theo.copy()
    df_rt = df_rt.copy()

    for col in ["expected_departure", "expected_arrival", "aimed_departure", "aimed_arrival"]:
        if col in df_rt.columns:
            df_rt[col] = pd.to_datetime(df_rt[col], errors="coerce")

    df_rt["event_time"] = (
        df_rt.get("expected_departure")
        .fillna(df_rt.get("expected_arrival"))
        .fillna(df_rt.get("aimed_departure"))
        .fillna(df_rt.get("aimed_arrival"))
    )

    df_rt = df_rt.dropna(subset=["event_time"]).copy()

    try:
        df_rt["event_time"] = df_rt["event_time"].dt.tz_localize(None)
    except (TypeError, AttributeError):
        pass

    reference_dt = df_rt["event_time"].min()
    reference_date = reference_dt.date()

    df_theo["stop_order"] = pd.to_numeric(df_theo["stop_order"], errors="coerce")
    df_theo = df_theo.dropna(subset=["stop_ref", "stop_order"]).copy()
    df_theo["stop_order"] = df_theo["stop_order"].astype(int)

    df_theo["planned_time_str"] = df_theo["planned_departure"].fillna(df_theo["planned_arrival"])
    df_theo["planned_time"] = pd.to_datetime(
        str(reference_date) + " " + df_theo["planned_time_str"].astype(str),
        errors="coerce",
    )
    df_theo = df_theo.dropna(subset=["planned_time"]).copy()

    return df_theo, df_rt, reference_dt